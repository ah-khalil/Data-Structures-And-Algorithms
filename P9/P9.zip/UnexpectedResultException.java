public class UnexpectedResultException extends RuntimeException
{
  public UnexpectedResultException() {
    super();
  }

  public UnexpectedResultException(String message) {
    super(message);
  }
}
